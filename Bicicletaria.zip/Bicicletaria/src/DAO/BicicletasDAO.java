
package DAO;

import Classes.Bicicletas;
import Conexao.Conexao;
import java.sql.Connection;
import java.sql.Date;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;

public class BicicletasDAO {
    
   
      
   private Connection conn;
     public BicicletasDAO() {
        try{
            this.conn = Conexao.getConnection();
        }catch(Exception e){
            System.out.println(e.getMessage());;
        }
    
    }
    
    public ArrayList listar() {
        PreparedStatement ps = null;
        Connection connL = null;
        ResultSet rs = null;
        ArrayList Bicicleta = new ArrayList();

        try {
            String SQL = "SELECT * FROM bicicletas ORDER BY cor";
            connL = this.conn;

            ps = connL.prepareStatement(SQL);
            rs = ps.executeQuery();

            while (rs.next()) {
                int id_bicicletas = rs.getInt("id_bicicleta");
                String modalidade = rs.getString("modalidade");
                String marca = rs.getString("marca");
                char seminova = rs.getString("seminova").charAt(0);
                String cor = rs.getString("cor");

                Bicicleta.add(new Bicicletas(id_bicicletas, modalidade, marca, seminova, cor));

            }

        } catch (SQLException sqle) {
            System.out.println(sqle.getMessage());
        } finally {
            Conexao.close(connL, ps);
        }

        return Bicicleta;
    }
    
    public void inserir(Bicicletas bicicletas) {         
        PreparedStatement ps = null;
        Connection connL = null;        
        if (bicicletas == null){
            System.out.println("O objeto bicicletas não pode ser nulo.");
        }
        try{
            String SQL = "INSERT INTO bicicletas (modalidade, marca, seminova, cor) " +
                    "values (?,?,?,?)";
            connL = this.conn;
            ps = connL.prepareStatement(SQL);           
            ps.setString(1, bicicletas.getModalidade());
            ps.setString(2, bicicletas.getMarca());
            ps.setString(3, bicicletas.getSeminova() + "");
            ps.setString(4, bicicletas.getCor());
            
            ps.executeUpdate();

        }catch(SQLException sqle){
            System.out.println("Erro ao inserir uma nova bicicleta" + sqle);
        }
        finally{
           Conexao.close(connL,ps);
        }
    }
    
    public Bicicletas procurar(int id_bicicletas) {
        PreparedStatement ps = null;
        Connection connL = null;
        ResultSet rs = null;
        Bicicletas bicicletas = new Bicicletas();
        bicicletas = null;

        try{
            String SQL = "SELECT id_bicicleta, modalidade, marca, seminova, cor FROM bicicletas WHERE id_bicicleta = ?";
            connL = this.conn;
            ps = connL.prepareStatement(SQL);
            ps.setInt(1, id_bicicletas);
            rs = ps.executeQuery();
           
            
           while (rs.next()) {
                int id_bicicleta = rs.getInt("id_bicicleta");
                String modalidade = rs.getString("modalidade");
                String marca = rs.getString("marca");
            char seminova = rs.getString("seminova").charAt(0);
                String cor = rs.getString("cor");

                bicicletas = new Bicicletas(id_bicicleta, modalidade, marca, seminova, cor);

            }
            
            
            
        }catch(SQLException sqle){
            System.out.println("Erro ao procurar bicicleta " + sqle);
        }
        
        return bicicletas;
    }
    
    public void excluir(int id_bicicleta){
        PreparedStatement ps = null;
        Connection connL = null;
       

        try{
            String SQL = "DELETE FROM bicicletas WHERE id_bicicleta=?";
            connL = this.conn;

            ps = connL.prepareStatement(SQL);
            ps.setInt(1,id_bicicleta);
            ps.executeUpdate();
        }catch(SQLException sqle){
          System.out.println("Erro ao excluir Bicicleta " + sqle);
        }
        finally{
          Conexao.close(connL,ps);
        }
    }
    
    public void atualizar(Bicicletas bicicletas) {
        PreparedStatement ps = null;
        Connection connL = null;
        if (bicicletas == null){
             System.out.println("O objeto bicicleta não pode ser nulo.");
        }

        try{
            String SQL = "UPDATE bicicletas set modalidade=?, marca=?, seminova=?, cor=? WHERE id_bicicleta=?";
            connL = this.conn;
          ps = connL.prepareStatement(SQL);           
            ps.setString(1, bicicletas.getModalidade());
            ps.setString(2, bicicletas.getMarca());
            ps.setString(3, bicicletas.getSeminova() + "");
            ps.setString(4, bicicletas.getCor());
            ps.setInt(5, bicicletas.getId_bicicleta());
            ps.executeUpdate();

        }catch(SQLException sqle){
            System.out.println("Erro ao editar Bicicletas " + sqle);
        }
        finally{
           Conexao.close(connL,ps);
        }
    }
}
    
