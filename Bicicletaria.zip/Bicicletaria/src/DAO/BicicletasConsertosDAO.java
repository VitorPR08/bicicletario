
package DAO;

import Classes.Bicicletas;
import Conexao.Conexao;
import Classes.BicicletasConsertos;
import Classes.Consertos;
import java.sql.Connection;
import java.sql.Date;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Time;
import java.util.ArrayList;


public class BicicletasConsertosDAO {
    
    
    private Connection conn;
    
    public BicicletasConsertosDAO() {
        try{
            this.conn = Conexao.getConnection();
        }catch(Exception e){
            System.out.println("Erro de conexão: " + ":\n" + e.getMessage());
        }
    }
    
    public ArrayList listar(int id_bicicletas) {
        PreparedStatement ps = null;
        Connection connL = null;
        ResultSet rs = null;
        ArrayList BicicletasCon = new ArrayList();

        try{
            String SQL = "SELECT bicicletas.id_bicicleta, bicicletas.marca, bicicletas.seminova, bicicletas.cor, consertos.descricao_servico, consertos.data, consertos.preco FROM bicicletas, consertos WHERE bicicletas.id_bicicleta = consertos.id_bicicleta and bicicletas.id_bicicleta = ?";
            connL = this.conn;
            ps = connL.prepareStatement(SQL);
            ps.setInt(1, id_bicicletas);
            rs = ps.executeQuery();

            

            while( rs.next()){
              int id_bicicleta = rs.getInt("id_bicicleta");
              String marca = rs.getString("marca");
              char seminova = rs.getString("seminova").charAt(0);
              String cor = rs.getString("cor");
              String descricao_servico = rs.getString("descricao_servico");
              Date data = rs.getDate("data");
              float preco = rs.getFloat("preco");
              
                
               BicicletasCon.add(new BicicletasConsertos(id_bicicleta, marca, seminova, cor, descricao_servico, data, preco));
              
            }


        }catch(SQLException sqle){
           System.out.println("Erro ao listar Consultas " + sqle);
        }
        finally{
           Conexao.close(connL,ps);
        }
         return BicicletasCon;
    }
    
    public ArrayList listarvec(int id_bicicletas) {
        PreparedStatement ps = null;
        Connection connL = null;
        ResultSet rs = null;
        ArrayList BicicletasCon = new ArrayList();

        try{
            String SQL = "SELECT bicicletas.id_bicicleta, bicicletas.marca, bicicletas.seminova, bicicletas.cor, consertos.descricao_servico, consertos.data, consertos.preco FROM bicicletas, clientes, consertos WHERE bicicletas.id_bicicleta = consertos.id_bicicleta and bicicletas.id_bicicleta = ?";
            connL = this.conn;
            ps = connL.prepareStatement(SQL);
            ps.setInt(1, id_bicicletas);
            rs = ps.executeQuery();
            
            while( rs.next()){
              int id_bicicleta = rs.getInt("id_bicicletas");
              String marca = rs.getString("marca");
               char seminova = rs.getString("seminova").charAt(0);
              String cor = rs.getString("cor");
              String descricao_servico = rs.getString("descricao_servico");
              Date data = rs.getDate("data");
              float preco = rs.getFloat("preco");
              

              BicicletasCon.add(new BicicletasConsertos(id_bicicleta, marca, seminova, cor, descricao_servico, data, preco));
              
            }


        }catch(SQLException sqle){
           System.out.println("Erro ao listar Consultas " + sqle);
        }
        finally{
           Conexao.close(connL,ps);
        }
         return BicicletasCon;
    }
    
    public ArrayList listarpordatav(java.util.Date data) {
        PreparedStatement ps = null;
        Connection connL = null;
        ResultSet rs = null;
        ArrayList BicicletasCon= new ArrayList();

        try{
            String SQL = "SELECT bicicletas.marca, bicicletas.seminova, bicicletas.cor, consertos.descricao_servico, consertos.data, consertos.preco FROM bicicletas, consertos WHERE bicicletas.id_bicicleta = consertos.id_veiculo and consertos.data = ?";
            connL = this.conn;
            ps = connL.prepareStatement(SQL);
            java.util.Date dataJAVA = data;
            java.sql.Date dataSQL = new java.sql.Date(dataJAVA.getTime());
            ps.setDate(1, dataSQL);
            rs = ps.executeQuery();
            while( rs.next()){
              int id_bicicletas = rs.getInt("id_bicicletas");
              String marca = rs.getString("marca");
               char seminova = rs.getString("seminova").charAt(0);
              String cor = rs.getString("cor");
              String descricao_servico = rs.getString("descricao_servico");
              Date dataa = rs.getDate("data");
              float preco = rs.getFloat("preco");
              

               BicicletasCon.add(new BicicletasConsertos(id_bicicletas, marca, seminova, cor, descricao_servico, dataa, preco));
              
            }


        }catch(SQLException sqle){
            System.out.println(sqle.getMessage());
        } finally {
            Conexao.close(connL, ps);
        }

        return BicicletasCon;
    }
    
    public Bicicletas procura(int id_bicicletas) {
        PreparedStatement ps = null;
        Connection connL = null;
        ResultSet rs = null;
        Bicicletas BicicletasCon = new Bicicletas();

        try{
            String SQL = "SELECT bicicletas.marca, bicicletas.id_bicicleta, consertos.descricao_servico, consertos.data, consertos.custo FROM bicicletas, consertos WHERE bicicletas.id_bicicleta = consertos.id_veiculo and bicicletas.id_bicicleta = ?";
            connL = this.conn;
            ps = connL.prepareStatement(SQL);
            ps.setInt(1, id_bicicletas);
            rs = ps.executeQuery();

            

            while( rs.next()){
              
             
            String marca = rs.getString("marca");
            int id = rs.getInt("id_bicicleta");
            String descricao_servico = rs.getString("descricao_servico");
            Date data = rs.getDate("data");
            float preco = rs.getFloat("preco");
              
             BicicletasCon.setMarca(marca);
             BicicletasCon.setId_bicicleta(id);
             
              
            }


        }catch(SQLException sqle){
           System.out.println("Erro ao listar Bicicletas " + sqle);
        }
        finally{
           Conexao.close(connL,ps);
        }
         return BicicletasCon;
    }
}
