
package Classes;

public class Bicicletas {
    
    int id_bicicleta;
    String modalidade;
    String marca;
    char seminova;
    String cor;

    public int getId_bicicleta() {
        return id_bicicleta;
    }

    public void setId_bicicleta(int id_bicicleta) {
        this.id_bicicleta = id_bicicleta;
    }

    public String getModalidade() {
        return modalidade;
    }

    public void setModalidade(String modalidade) {
        this.modalidade = modalidade;
    }

    public String getMarca() {
        return marca;
    }

    public void setMarca(String marca) {
        this.marca = marca;
    }

    public char getSeminova() {
        return seminova;
    }

    public void setSeminova(char seminova) {
        this.seminova = seminova;
    }

    public String getCor() {
        return cor;
    }

    public void setCor(String cor) {
        this.cor = cor;
    }

    public Bicicletas() {
    }

    public Bicicletas(int id_bicicleta, String modalidade, String marca, char seminova, String cor) {
        this.id_bicicleta = id_bicicleta;
        this.modalidade = modalidade;
        this.marca = marca;
        this.seminova = seminova;
        this.cor = cor;
    }

    
}
