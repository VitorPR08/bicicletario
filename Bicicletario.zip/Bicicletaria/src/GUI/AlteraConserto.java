package GUI;

import Classes.Consertos;
import DAO.ConsertosDAO;
import java.awt.Dimension;
import java.text.DateFormat;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Date;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.swing.JOptionPane;

public class AlteraConserto extends javax.swing.JFrame {

    private Consertos C = new Consertos();
    int id, posicao;
    private static ArrayList<Consertos> cliente = new ArrayList<Consertos>();

    public AlteraConserto() {

        initComponents();
        pack();
        setMinimumSize(new Dimension(700, 500));
        setLocationRelativeTo(null);

    }

    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        OK = new javax.swing.JButton();
        CAN = new javax.swing.JButton();
        COMBO = new javax.swing.JComboBox<>();
        COMBOB = new javax.swing.JComboBox<>();
        COMBOC = new javax.swing.JComboBox<>();
        jLabel1 = new javax.swing.JLabel();
        T1 = new javax.swing.JTextField();
        T2 = new javax.swing.JTextField();
        jLabel2 = new javax.swing.JLabel();
        DC = new datechooser.beans.DateChooserPanel();
        jLabel3 = new javax.swing.JLabel();
        jLabel4 = new javax.swing.JLabel();
        jLabel5 = new javax.swing.JLabel();

        addComponentListener(new java.awt.event.ComponentAdapter() {
            public void componentShown(java.awt.event.ComponentEvent evt) {
                formComponentShown(evt);
            }
        });

        OK.setText("OK");
        OK.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                OKMouseClicked(evt);
            }
        });

        CAN.setText("Cancelar");
        CAN.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                CANMouseClicked(evt);
            }
        });

        COMBO.addItemListener(new java.awt.event.ItemListener() {
            public void itemStateChanged(java.awt.event.ItemEvent evt) {
                COMBOItemStateChanged(evt);
            }
        });

        COMBOB.addItemListener(new java.awt.event.ItemListener() {
            public void itemStateChanged(java.awt.event.ItemEvent evt) {
                COMBOBItemStateChanged(evt);
            }
        });

        COMBOC.addItemListener(new java.awt.event.ItemListener() {
            public void itemStateChanged(java.awt.event.ItemEvent evt) {
                COMBOCItemStateChanged(evt);
            }
        });
        COMBOC.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                COMBOCActionPerformed(evt);
            }
        });

        jLabel1.setText("Custo");

        T1.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                T1ActionPerformed(evt);
            }
        });

        jLabel2.setText("Descricao servico");

        jLabel3.setText("id_conserto");

        jLabel4.setText("id_bicicleta");

        jLabel5.setText("id_cliente");

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addGap(15, 15, 15)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(layout.createSequentialGroup()
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addGroup(layout.createSequentialGroup()
                                .addGap(11, 11, 11)
                                .addComponent(jLabel1, javax.swing.GroupLayout.PREFERRED_SIZE, 48, javax.swing.GroupLayout.PREFERRED_SIZE))
                            .addComponent(jLabel2))
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, 38, Short.MAX_VALUE)
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                            .addComponent(T1, javax.swing.GroupLayout.DEFAULT_SIZE, 248, Short.MAX_VALUE)
                            .addComponent(T2))
                        .addGap(41, 41, 41)
                        .addComponent(DC, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addContainerGap())
                    .addGroup(layout.createSequentialGroup()
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                            .addGroup(layout.createSequentialGroup()
                                .addComponent(jLabel5)
                                .addGap(28, 28, 28)
                                .addComponent(COMBOC, javax.swing.GroupLayout.PREFERRED_SIZE, 310, javax.swing.GroupLayout.PREFERRED_SIZE))
                            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, layout.createSequentialGroup()
                                .addComponent(jLabel3)
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                                .addComponent(COMBO, javax.swing.GroupLayout.PREFERRED_SIZE, 310, javax.swing.GroupLayout.PREFERRED_SIZE))
                            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, layout.createSequentialGroup()
                                .addComponent(jLabel4)
                                .addGap(18, 18, 18)
                                .addComponent(COMBOB, javax.swing.GroupLayout.PREFERRED_SIZE, 310, javax.swing.GroupLayout.PREFERRED_SIZE)))
                        .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
                    .addGroup(layout.createSequentialGroup()
                        .addComponent(CAN)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                        .addComponent(OK)
                        .addGap(33, 33, 33))))
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, layout.createSequentialGroup()
                .addGap(18, 18, 18)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(COMBO, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(jLabel3))
                .addGap(18, 18, 18)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(COMBOB, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(jLabel4))
                .addGap(18, 18, 18)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(COMBOC, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(jLabel5))
                .addGap(18, 18, 18)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(layout.createSequentialGroup()
                        .addGap(0, 84, Short.MAX_VALUE)
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(T1, javax.swing.GroupLayout.PREFERRED_SIZE, 56, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(jLabel1, javax.swing.GroupLayout.PREFERRED_SIZE, 36, javax.swing.GroupLayout.PREFERRED_SIZE))
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(T2, javax.swing.GroupLayout.PREFERRED_SIZE, 94, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addGroup(layout.createSequentialGroup()
                                .addGap(48, 48, 48)
                                .addComponent(jLabel2)))
                        .addGap(53, 53, 53))
                    .addGroup(layout.createSequentialGroup()
                        .addComponent(DC, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)))
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(CAN)
                    .addComponent(OK))
                .addGap(17, 17, 17))
        );
    }// </editor-fold>//GEN-END:initComponents

    private void OKMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_OKMouseClicked
        Consertos C = new Consertos();
        String aux;
        C.setId_conserto(id);
        if (T1.getText().equals("")) {
            JOptionPane.showMessageDialog(rootPane, "O Campo preco nÃ£o pode estar vazio");
        } else {
            aux = T1.getText();
            C.setPreco(Float.parseFloat(aux));
            C.setDescricao_servico(T2.getText());
            C.setId_bicicleta(Integer.parseInt((String) COMBOB.getSelectedItem()));
            C.setId_cliente(Integer.parseInt((String) COMBOC.getSelectedItem()));
            Calendar calendar = DC.getSelectedDate();
            Date data = calendar.getTime();
            DateFormat formato = new SimpleDateFormat("dd/MM/yyyy");
            String formatada = formato.format(data);
            try {
                Date datas = formato.parse(formatada);
                C.setData(datas);
            } catch (ParseException ex) {
                Logger.getLogger(InsereConsertos.class.getName()).log(Level.SEVERE, null, ex);
            }
            ConsertosDAO PDAO = new ConsertosDAO();
            PDAO.atualizar(C);
            JOptionPane.showMessageDialog(rootPane, "AtualizaÃ§Ã£o efetuada com sucesso!!");
            dispose();

        }
    }//GEN-LAST:event_OKMouseClicked

    private void formComponentShown(java.awt.event.ComponentEvent evt) {//GEN-FIRST:event_formComponentShown
        carregaCombo();
        carrega();
    }//GEN-LAST:event_formComponentShown

    private void CANMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_CANMouseClicked
        dispose();
    }//GEN-LAST:event_CANMouseClicked

    private void COMBOItemStateChanged(java.awt.event.ItemEvent evt) {//GEN-FIRST:event_COMBOItemStateChanged
        int posicao = COMBO.getSelectedIndex();
        if (!cliente.isEmpty() && posicao != -1 && posicao < cliente.size()) {
            id = cliente.get(posicao).getId_conserto();
            carrega();
        }

    }//GEN-LAST:event_COMBOItemStateChanged

    private void COMBOBItemStateChanged(java.awt.event.ItemEvent evt) {//GEN-FIRST:event_COMBOBItemStateChanged
        int posicao = COMBOB.getSelectedIndex();
        if (!cliente.isEmpty() && posicao != -1 && posicao < cliente.size()) {
            id = cliente.get(posicao).getId_bicicleta();
            carrega();
        }
    }//GEN-LAST:event_COMBOBItemStateChanged

    private void COMBOCItemStateChanged(java.awt.event.ItemEvent evt) {//GEN-FIRST:event_COMBOCItemStateChanged
        int posicao = COMBOC.getSelectedIndex();
        if (!cliente.isEmpty() && posicao != -1 && posicao < cliente.size()) {
            id = cliente.get(posicao).getId_cliente();
            carrega();
        }
    }//GEN-LAST:event_COMBOCItemStateChanged

    private void T1ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_T1ActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_T1ActionPerformed

    private void COMBOCActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_COMBOCActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_COMBOCActionPerformed
    public void carregaCombo() {
        COMBO.removeAllItems();
        ConsertosDAO CDAO = new ConsertosDAO();
        cliente = CDAO.listar();
        for (int i = 0; i < cliente.size(); i++) {
            COMBO.addItem(String.valueOf(cliente.get(i).getId_conserto()));
            COMBOB.addItem(String.valueOf(cliente.get(i).getId_bicicleta()));
            COMBOC.addItem(String.valueOf(cliente.get(i).getId_cliente()));
        }
    }

    public void carrega() {
        ConsertosDAO CDAO = new ConsertosDAO();
        C = CDAO.procurar(id);
        T1.setText(String.valueOf(C.getPreco()));
        T2.setText(C.getDescricao_servico());
    }


    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JButton CAN;
    private javax.swing.JComboBox<String> COMBO;
    private javax.swing.JComboBox<String> COMBOB;
    private javax.swing.JComboBox<String> COMBOC;
    private datechooser.beans.DateChooserPanel DC;
    private javax.swing.JButton OK;
    private javax.swing.JTextField T1;
    private javax.swing.JTextField T2;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JLabel jLabel2;
    private javax.swing.JLabel jLabel3;
    private javax.swing.JLabel jLabel4;
    private javax.swing.JLabel jLabel5;
    // End of variables declaration//GEN-END:variables
}
