
package GUI;

import Classes.Consertos;
import DAO.ConsertosDAO;
import java.awt.Dimension;
import java.util.ArrayList;
import javax.swing.DefaultListModel;


public class ListaConsertos extends javax.swing.JFrame {
    private Consertos con = new Consertos();
int id, pos;
private static ArrayList<Consertos> conserto = new ArrayList<Consertos>();
private static ArrayList<Consertos> Consulta = new ArrayList<Consertos>();
private static ArrayList<Consertos> Aux = new ArrayList<Consertos>();
private static DefaultListModel Valores = new DefaultListModel();
private static int codigo = 0;
private static int posicao,posicon;

    public ListaConsertos() {
        initComponents();
        pack();
        setMinimumSize(new Dimension(700, 500));
        setLocationRelativeTo(null);
    }
    
    public void carregaConsertos(){
             
        Lista.removeAll();
        if (posicao != -1) {
            
            try {
                ConsertosDAO CDAO = new ConsertosDAO();
                Aux = CDAO.listar(codigo);
            } catch (Exception ex) {
                System.out.println("problema");
            }
            Valores.clear();
            for (int i = 0; i < Aux.size(); i++) {
                Valores.addElement(Aux.get(i).getId_bicicleta()+"--"+Aux.get(i).getId_cliente()+"--"+Aux.get(i).getData()+"--"+Aux.get(i).getPreco()+"--"+Aux.get(i).getDescricao_servico());
            }
            Lista.setModel(Valores);
        }

    }

   
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jLabel1 = new javax.swing.JLabel();
        ComboConserto = new javax.swing.JComboBox<>();
        jScrollPane1 = new javax.swing.JScrollPane();
        Lista = new javax.swing.JList<>();
        CAN = new javax.swing.JButton();
        jLabel2 = new javax.swing.JLabel();
        jLabel3 = new javax.swing.JLabel();
        jLabel4 = new javax.swing.JLabel();
        jLabel5 = new javax.swing.JLabel();
        jLabel6 = new javax.swing.JLabel();
        jLabel7 = new javax.swing.JLabel();

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);
        addWindowListener(new java.awt.event.WindowAdapter() {
            public void windowOpened(java.awt.event.WindowEvent evt) {
                formWindowOpened(evt);
            }
        });

        jLabel1.setText("Lista de Consertos(por ID)");

        ComboConserto.setModel(new javax.swing.DefaultComboBoxModel<>(new String[] { "Item 1", "Item 2", "Item 3", "Item 4" }));
        ComboConserto.addItemListener(new java.awt.event.ItemListener() {
            public void itemStateChanged(java.awt.event.ItemEvent evt) {
                ComboConsertoItemStateChanged(evt);
            }
        });
        ComboConserto.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                ComboConsertoActionPerformed(evt);
            }
        });

        jScrollPane1.setViewportView(Lista);

        CAN.setText("sair");
        CAN.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                CANMouseClicked(evt);
            }
        });
        CAN.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                CANActionPerformed(evt);
            }
        });

        jLabel2.setText("id_bicicleta");

        jLabel3.setText("id_cliente");

        jLabel4.setText("data");

        jLabel5.setText("preco");

        jLabel6.setText("descricao serviço");

        jLabel7.setText("id_conserto");

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(jScrollPane1, javax.swing.GroupLayout.Alignment.TRAILING)
                    .addGroup(layout.createSequentialGroup()
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addGroup(layout.createSequentialGroup()
                                .addGap(191, 191, 191)
                                .addComponent(jLabel1))
                            .addGroup(layout.createSequentialGroup()
                                .addGap(232, 232, 232)
                                .addComponent(CAN))
                            .addGroup(layout.createSequentialGroup()
                                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                    .addGroup(layout.createSequentialGroup()
                                        .addGap(38, 38, 38)
                                        .addComponent(jLabel2, javax.swing.GroupLayout.PREFERRED_SIZE, 74, javax.swing.GroupLayout.PREFERRED_SIZE)
                                        .addGap(44, 44, 44))
                                    .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, layout.createSequentialGroup()
                                        .addContainerGap()
                                        .addComponent(jLabel7)
                                        .addGap(54, 54, 54)))
                                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                    .addGroup(layout.createSequentialGroup()
                                        .addComponent(jLabel3)
                                        .addGap(37, 37, 37)
                                        .addComponent(jLabel4))
                                    .addComponent(ComboConserto, javax.swing.GroupLayout.PREFERRED_SIZE, 222, javax.swing.GroupLayout.PREFERRED_SIZE))))
                        .addGap(0, 176, Short.MAX_VALUE)))
                .addContainerGap())
            .addGroup(layout.createSequentialGroup()
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addComponent(jLabel5)
                .addGap(52, 52, 52)
                .addComponent(jLabel6)
                .addGap(70, 70, 70))
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addContainerGap()
                .addComponent(jLabel1)
                .addGap(18, 18, 18)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(ComboConserto, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(jLabel7))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, 96, Short.MAX_VALUE)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel2, javax.swing.GroupLayout.PREFERRED_SIZE, 16, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(jLabel3)
                    .addComponent(jLabel4)
                    .addComponent(jLabel5)
                    .addComponent(jLabel6))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addComponent(jScrollPane1, javax.swing.GroupLayout.PREFERRED_SIZE, 159, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(18, 18, 18)
                .addComponent(CAN))
        );

        pack();
    }// </editor-fold>//GEN-END:initComponents

    private void ComboConsertoActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_ComboConsertoActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_ComboConsertoActionPerformed

    private void ComboConsertoItemStateChanged(java.awt.event.ItemEvent evt) {//GEN-FIRST:event_ComboConsertoItemStateChanged
         posicon = ComboConserto.getSelectedIndex();
    
    if (posicon != -1 && !conserto.isEmpty()) { // verifica se tem item selecionado e se a lista não está vazia
        codigo = conserto.get(posicon).getId_conserto();
        carregaConsertos();
    }
    }//GEN-LAST:event_ComboConsertoItemStateChanged

    private void CANActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_CANActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_CANActionPerformed

    private void CANMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_CANMouseClicked
        dispose();
    }//GEN-LAST:event_CANMouseClicked

    private void formWindowOpened(java.awt.event.WindowEvent evt) {//GEN-FIRST:event_formWindowOpened
       carregaCombo();
    }//GEN-LAST:event_formWindowOpened

     public void carregaCombo() {
        ComboConserto.removeAllItems();
        ConsertosDAO MDAO = new ConsertosDAO();
        conserto = MDAO.listar();
        
        for (int i = 0; i < conserto.size(); i++) {
            ComboConserto.addItem(String.valueOf(conserto.get(i).getId_conserto()));

        }
    }
    

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JButton CAN;
    private javax.swing.JComboBox<String> ComboConserto;
    private javax.swing.JList<String> Lista;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JLabel jLabel2;
    private javax.swing.JLabel jLabel3;
    private javax.swing.JLabel jLabel4;
    private javax.swing.JLabel jLabel5;
    private javax.swing.JLabel jLabel6;
    private javax.swing.JLabel jLabel7;
    private javax.swing.JScrollPane jScrollPane1;
    // End of variables declaration//GEN-END:variables
}
