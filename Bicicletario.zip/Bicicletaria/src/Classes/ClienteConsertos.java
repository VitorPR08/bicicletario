
package Classes;

import java.util.Date;


public class ClienteConsertos {
    int id_cliente;
    String nome;
    String endereco;
    String telefone;
    int id_conserto;
    int ID_cliente;
    int id_bicicleta;
    String descricao_servico;
    Date data;
    float preco;

    public int getId_cliente() {
        return id_cliente;
    }

    public void setId_cliente(int id_cliente) {
        this.id_cliente = id_cliente;
    }

    public String getNome() {
        return nome;
    }

    public void setNome(String nome) {
        this.nome = nome;
    }

    public String getEndereco() {
        return endereco;
    }

    public void setEndereco(String endereco) {
        this.endereco = endereco;
    }

    public String getTelefone() {
        return telefone;
    }

    public void setTelefone(String telefone) {
        this.telefone = telefone;
    }

    public int getId_conserto() {
        return id_conserto;
    }

    public void setId_conserto(int id_conserto) {
        this.id_conserto = id_conserto;
    }

    public int getID_cliente() {
        return ID_cliente;
    }

    public void setID_cliente(int ID_cliente) {
        this.ID_cliente = ID_cliente;
    }

    public int getId_bicicleta() {
        return id_bicicleta;
    }

    public void setId_bicicleta(int id_bicicleta) {
        this.id_bicicleta = id_bicicleta;
    }

    public String getDescricao_servico() {
        return descricao_servico;
    }

    public void setDescricao_servico(String descricao_servico) {
        this.descricao_servico = descricao_servico;
    }

    public Date getData() {
        return data;
    }

    public void setData(Date data) {
        this.data = data;
    }

    public float getPreco() {
        return preco;
    }

    public void setPreco(float preco) {
        this.preco = preco;
    }

    public ClienteConsertos() {
    }

    public ClienteConsertos(int id_cliente, String nome, String endereco, String telefone, int id_conserto, int ID_cliente, int id_bicicleta, String descricao_servico, Date data, float preco) {
        this.id_cliente = id_cliente;
        this.nome = nome;
        this.endereco = endereco;
        this.telefone = telefone;
        this.id_conserto = id_conserto;
        this.ID_cliente = ID_cliente;
        this.id_bicicleta = id_bicicleta;
        this.descricao_servico = descricao_servico;
        this.data = data;
        this.preco = preco;
    }

    public ClienteConsertos(int id_cliente, String nome, String endereco, String telefone) {
        this.id_cliente = id_cliente;
        this.nome = nome;
        this.endereco = endereco;
        this.telefone = telefone;
    }

    public ClienteConsertos(int id_cliente, String nome, String descricao_servico, Date data, float preco) {
        this.id_cliente = id_cliente;
        this.nome = nome;
        this.descricao_servico = descricao_servico;
        this.data = data;
        this.preco = preco;
    }

    
    
    

    public ClienteConsertos(int id_cliente, String nome, String endereco, String telefone, String descricao_servico, Date data, float preco) {
        this.id_cliente = id_cliente;
        this.nome = nome;
        this.endereco = endereco;
        this.telefone = telefone;
        this.descricao_servico = descricao_servico;
        this.data = data;
        this.preco = preco;
    }
    
    
}
