
package Classes;

import java.util.Date;


public class Consertos {
     int id_conserto;
    int id_cliente;
    int id_bicicleta;
    String descricao_servico;
    Date data;
    float preco;

    public int getId_conserto() {
        return id_conserto;
    }

    public void setId_conserto(int id_conserto) {
        this.id_conserto = id_conserto;
    }

    public int getId_cliente() {
        return id_cliente;
    }

    public void setId_cliente(int id_cliente) {
        this.id_cliente = id_cliente;
    }

    public int getId_bicicleta() {
        return id_bicicleta;
    }

    public void setId_bicicleta(int id_bicicleta) {
        this.id_bicicleta = id_bicicleta;
    }

    public String getDescricao_servico() {
        return descricao_servico;
    }

    public void setDescricao_servico(String descricao_servico) {
        this.descricao_servico = descricao_servico;
    }

    public Date getData() {
        return data;
    }

    public void setData(Date data) {
        this.data = data;
    }

    public float getPreco() {
        return preco;
    }

    public void setPreco(float preco) {
        this.preco = preco;
    }

    public Consertos() {
    }

    public Consertos(int id_conserto, int id_cliente, int id_bicicleta, String descricao_servico, Date data, float preco) {
        this.id_conserto = id_conserto;
        this.id_cliente = id_cliente;
        this.id_bicicleta = id_bicicleta;
        this.descricao_servico = descricao_servico;
        this.data = data;
        this.preco = preco;
    }
    
}
