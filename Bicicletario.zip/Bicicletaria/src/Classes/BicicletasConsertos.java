
package Classes;

import java.util.Date;


public class BicicletasConsertos {
    int id_bicicleta;
    String modalidade;
    String marca;
    char seminova;
    String cor;
    int id_conserto;
    int id_cliente;
    int ID_bicicleta;
    String descricao_servico;
    Date data;
    float preco;

    public int getId_bicicleta() {
        return id_bicicleta;
    }

    public void setId_bicicleta(int id_bicicleta) {
        this.id_bicicleta = id_bicicleta;
    }

    public String getModalidade() {
        return modalidade;
    }

    public void setModalidade(String modalidade) {
        this.modalidade = modalidade;
    }

    public String getMarca() {
        return marca;
    }

    public void setMarca(String marca) {
        this.marca = marca;
    }

    public char getSeminova() {
        return seminova;
    }

    public void setSeminova(char seminova) {
        this.seminova = seminova;
    }

    public String getCor() {
        return cor;
    }

    public void setCor(String cor) {
        this.cor = cor;
    }

    public int getId_conserto() {
        return id_conserto;
    }

    public void setId_conserto(int id_conserto) {
        this.id_conserto = id_conserto;
    }

    public int getId_cliente() {
        return id_cliente;
    }

    public void setId_cliente(int id_cliente) {
        this.id_cliente = id_cliente;
    }

    public int getID_bicicleta() {
        return ID_bicicleta;
    }

    public void setID_bicicleta(int ID_bicicleta) {
        this.ID_bicicleta = ID_bicicleta;
    }

    public String getDescricao_servico() {
        return descricao_servico;
    }

    public void setDescricao_servico(String descricao_servico) {
        this.descricao_servico = descricao_servico;
    }

    public Date getData() {
        return data;
    }

    public void setData(Date data) {
        this.data = data;
    }

    public float getPreco() {
        return preco;
    }

    public void setPreco(float preco) {
        this.preco = preco;
    }

    public BicicletasConsertos() {
    }

    
    public BicicletasConsertos(int id_bicicleta, String modalidade, String marca, char seminova, String cor, int id_conserto, int id_cliente, int ID_bicicleta, String descricao_servico, Date data, float preco) {
        this.id_bicicleta = id_bicicleta;
        this.modalidade = modalidade;
        this.marca = marca;
        this.seminova = seminova;
        this.cor = cor;
        this.id_conserto = id_conserto;
        this.id_cliente = id_cliente;
        this.ID_bicicleta = ID_bicicleta;
        this.descricao_servico = descricao_servico;
        this.data = data;
        this.preco = preco;
    }

    public BicicletasConsertos(int id_bicicleta, String marca, char seminova, String cor, String descricao_servico, Date data, float preco) {
        this.id_bicicleta = id_bicicleta;
        this.marca = marca;
        this.seminova = seminova;
        this.cor = cor;
        this.descricao_servico = descricao_servico;
        this.data = data;
        this.preco = preco;
    }
    
    

    public BicicletasConsertos(int id_bicicleta, String modalidade, String marca, char seminova, String cor, String descricao_servico, Date data, float preco) {
        this.id_bicicleta = id_bicicleta;
        this.modalidade = modalidade;
        this.marca = marca;
        this.seminova = seminova;
        this.cor = cor;
        this.descricao_servico = descricao_servico;
        this.data = data;
        this.preco = preco;
    }
}
