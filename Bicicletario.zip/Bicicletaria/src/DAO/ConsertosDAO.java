

package DAO;

import Classes.Consertos;
import Conexao.Conexao;
import java.sql.Connection;
import java.sql.Date;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;

public class ConsertosDAO {
    
    private Connection conn;
     public ConsertosDAO() {
        try{
            this.conn = Conexao.getConnection();
        }catch(Exception e){
            System.out.println(e.getMessage());;
        }
    }
     
     public ArrayList listar() {
        PreparedStatement ps = null;
        Connection connL = null;
        ResultSet rs = null;
        ArrayList Conserto = new ArrayList();

        try {
            String SQL = "SELECT * FROM consertos ORDER BY data ASC";
            connL = this.conn;

            ps = connL.prepareStatement(SQL);
            rs = ps.executeQuery();

            while (rs.next()) {
                int id_conserto = rs.getInt("id_conserto");
                int id_bicicleta = rs.getInt("id_bicicleta");
                int id_cliente = rs.getInt("id_cliente");
                Date data = rs.getDate("data");
                String descricao_servico = rs.getString("descricao_servico");
                float preco = rs.getFloat("preco");

                Conserto.add(new Consertos(id_conserto, id_cliente ,id_bicicleta, descricao_servico, data , preco));

            }

        } catch (SQLException sqle) {
            System.out.println(sqle.getMessage());
        } finally {
            Conexao.close(connL, ps);
        }

        return Conserto;
    }
     
     public void inserir(Consertos consertos) {         
        PreparedStatement ps = null;
        Connection connL = null;        
        if (consertos == null){
            System.out.println("O objeto consertos não pode ser nulo.");
        }
        try{
            String SQL = "INSERT INTO consertos (id_bicicleta, id_cliente, data, descricao_servico, preco) " +
                    "values (?,?,?,?,?)";
            connL = this.conn;
            ps = connL.prepareStatement(SQL);
            ps.setInt(1, consertos.getId_bicicleta());
            ps.setInt(2, consertos.getId_cliente());
            java.util.Date dataJAVA = consertos.getData(); 
            java.sql.Date dataSQL = new java.sql.Date(dataJAVA.getTime()); 
            ps.setDate(3, dataSQL);
            ps.setString(4, consertos.getDescricao_servico());
            ps.setFloat(5, consertos.getPreco());
            ps.executeUpdate();

        }catch(SQLException sqle){
            System.out.println("Erro ao inserir um bicicleta" + sqle);
        }
        finally{
           Conexao.close(connL,ps);
        }
    }
     
     public Consertos procurar(int id_conserto) {
        PreparedStatement ps = null;
        Connection connL = null;
        ResultSet rs = null;
        Consertos consertos = new Consertos();
        consertos = null;

        try{
            String SQL = "SELECT id_conserto, id_bicicleta, id_cliente, data, descricao_servico, preco FROM consertos WHERE id_conserto = ?";
            connL = this.conn;
            ps = connL.prepareStatement(SQL);
            ps.setInt(1, id_conserto);
            rs = ps.executeQuery();
           
            
           while (rs.next()) {
                int id_consertos = rs.getInt("id_conserto");
                int id_bicicleta = rs.getInt("id_bicicleta");
                int id_cliente = rs.getInt("id_cliente");
                Date data = rs.getDate("data");
                String descricao_servico = rs.getString("descricao_servico");
                float preco = rs.getFloat("preco");

                consertos = new Consertos(id_conserto, id_cliente ,id_bicicleta, descricao_servico, data , preco);

            }
           
           }catch(SQLException sqle){
            System.out.println("Erro ao procurar bicicleta " + sqle);
        }
        finally{
          // ConexaoAulaDAO.close(connL,ps);
        }
        return consertos;
    }   
     
     public void excluir(int id_manutencao){
        PreparedStatement ps = null;
        Connection connL = null;

        try{
            String SQL = "DELETE FROM consertos WHERE id_conserto=?";
            connL = this.conn;

            ps = connL.prepareStatement(SQL);
            ps.setInt(1, id_manutencao);
            ps.executeUpdate();
        }catch(SQLException sqle){
          System.out.println("Erro ao excluir conserto " + sqle);
        }
        finally{
          Conexao.close(connL,ps);
        }
    }
     
     public void atualizar(Consertos consertos) {
        PreparedStatement ps = null;
        Connection connL = null;
        if (consertos == null){
             System.out.println("O objeto Conserto não pode ser nulo.");
        }

        try{
            String SQL = "UPDATE consertos set id_bicicleta=?, id_cliente=?, data=?, descricao_servico=?, preco=? WHERE id_conserto=?";
            connL = this.conn;
            ps = connL.prepareStatement(SQL);           
            ps.setInt(1, consertos.getId_bicicleta());
            ps.setInt(2, consertos.getId_cliente());
            java.util.Date dataJAVA = consertos.getData(); 
            java.sql.Date dataSQL = new java.sql.Date(dataJAVA.getTime()); 
            ps.setDate(3, dataSQL);
            ps.setString(4, consertos.getDescricao_servico());
            ps.setFloat(5, consertos.getPreco());
            ps.setInt(6, consertos.getId_conserto());
            ps.executeUpdate();

        }catch(SQLException sqle){
            System.out.println("Erro ao editar consertos " + sqle);
        }
        finally{
           Conexao.close(connL,ps);
        }
    }
     
     public ArrayList listar(int id_conserto) {
        PreparedStatement ps = null;
        Connection connL = null;
        ResultSet rs = null;
        ArrayList Conserto = new ArrayList();

        try {
            String SQL = "SELECT * FROM consertos ORDER BY data ASC";
            connL = this.conn;

            ps = connL.prepareStatement(SQL);
            rs = ps.executeQuery();

            while (rs.next()) {
                 id_conserto = rs.getInt("id_conserto");
                int id_bicicleta = rs.getInt("id_bicicleta");
                int id_cliente = rs.getInt("id_cliente");
                Date data = rs.getDate("data");
                String descricao_servico = rs.getString("descricao_servico");
                float preco = rs.getFloat("preco");

                Conserto.add(new Consertos(id_conserto,  id_cliente,  id_bicicleta, descricao_servico, data, preco));

            }

        } catch (SQLException sqle) {
            System.out.println(sqle.getMessage());
        } finally {
            Conexao.close(connL, ps);
        }

        return Conserto;
    }
   }


