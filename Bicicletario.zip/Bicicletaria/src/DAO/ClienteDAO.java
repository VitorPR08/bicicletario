
package DAO;

import Classes.Cliente;
import Conexao.Conexao;
import java.sql.Connection;
import java.sql.Date;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;

public class ClienteDAO {
    
    private Connection conn;
     public ClienteDAO() {
        try{
            this.conn = Conexao.getConnection();
        }catch(Exception e){
            System.out.println(e.getMessage());;
        }
    }
     
     public ArrayList listar() {
        PreparedStatement ps = null;
        Connection connL = null;
        ResultSet rs = null;
        ArrayList Cliente = new ArrayList();

        try {
            String SQL = "SELECT * FROM cliente ORDER BY nome";
            connL = this.conn;

            ps = connL.prepareStatement(SQL);
            rs = ps.executeQuery();

            while (rs.next()) {
                int id_cliente = rs.getInt("id_cliente");
                String nome = rs.getString("nome");
                String endereco = rs.getString("endereco");
                String telefone = rs.getString("telefone");

                Cliente.add(new Cliente(id_cliente, nome, endereco, telefone));

            }

        } catch (SQLException sqle) {
            System.out.println(sqle.getMessage());
        } finally {
            Conexao.close(connL, ps);
        }

        return Cliente;
    }
     
     public void inserir(Cliente cliente) {         
        PreparedStatement ps = null;
        Connection connL = null;        
        if (cliente == null){
            System.out.println("O objeto cliente não pode ser nulo.");
        }
        try{
            String SQL = "INSERT INTO cliente (nome, endereco, telefone) " +
                    "values (?,?,?)";
            connL = this.conn;
            ps = connL.prepareStatement(SQL);           
            ps.setString(1, cliente.getNome());
            ps.setString(2, cliente.getEndereco());
	    ps.setString(3, cliente.getTelefone());
            ps.executeUpdate();

        }catch(SQLException sqle){
            System.out.println("Erro ao inserir um novo cliente" + sqle);
        }
        finally{
           Conexao.close(connL,ps);
        }
    }
     
     public Cliente procurar(int id_cliente) {
        PreparedStatement ps = null;
        Connection connL = null;
        ResultSet rs = null;
        Cliente cliente = new Cliente();
        cliente = null;

        try{
            String SQL = "SELECT id_cliente, nome, endereco, telefone FROM cliente WHERE id_cliente = ?";
            connL = this.conn;
            ps = connL.prepareStatement(SQL);
            ps.setInt(1, id_cliente);
            rs = ps.executeQuery();
           
            
            while (rs.next()) {
                int id = rs.getInt("id_cliente");
                String nome = rs.getString("nome");
                String endereco = rs.getString("endereco");
                String telefone = rs.getString("telefone");

                cliente = new Cliente(id, nome, endereco, telefone);

            }
            
            
            
        }catch(SQLException sqle){
            System.out.println("Erro ao procurar cliente " + sqle);
        }
        finally{
          // ConexaoAulaDAO.close(connL,ps);
        }
        return cliente;
    } 
     
      public void excluir(int id_cliente){
        PreparedStatement ps = null;
        Connection connL = null;
        

        try{
            String SQL = "DELETE FROM cliente WHERE id_cliente=?";
            connL = this.conn;

            ps = connL.prepareStatement(SQL);
            ps.setInt(1,id_cliente);
            ps.executeUpdate();
        }catch(SQLException sqle){
          System.out.println("Erro ao excluir Cliente " + sqle);
        }
        finally{
          Conexao.close(connL,ps);
        }
    }
      
      public void atualizar(Cliente cliente) {
        PreparedStatement ps = null;
        Connection connL = null;
        if (cliente == null){
             System.out.println("O objeto Cliente não pode ser nulo.");
        }

        try{
            String SQL = "UPDATE cliente set nome=?, endereco=?, telefone=? WHERE id_cliente=?";
            connL = this.conn;
           ps = connL.prepareStatement(SQL);           
            ps.setString(1, cliente.getNome());
            ps.setString(2, cliente.getEndereco());
	    ps.setString(3, cliente.getTelefone());
            ps.setInt(4, cliente.getId_cliente());
            ps.executeUpdate();

        }catch(SQLException sqle){
            System.out.println("Erro ao editar Cliente " + sqle);
        }
        finally{
           Conexao.close(connL,ps);
        }
    }
  }
