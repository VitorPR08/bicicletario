
package DAO;

import Classes.Cliente;
import Conexao.Conexao;
import Classes.ClienteConsertos;
import Classes.Consertos;
import java.sql.Connection;
import java.sql.Date;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Time;
import java.util.ArrayList;

public class ClienteConsertosDAO {
    
    private Connection conn;
    
    public ClienteConsertosDAO() {
        try{
            this.conn = Conexao.getConnection();
        }catch(Exception e){
            System.out.println("Erro de conexão: " + ":\n" + e.getMessage());
        }
    }
    
    public ArrayList listar(int id_cliente) {
        PreparedStatement ps = null;
        Connection connL = null;
        ResultSet rs = null;
        ArrayList ClienteCon = new ArrayList();

        try{
            String SQL = "SELECT cliente.id_cliente,cliente.nome, cliente.endereco, cliente.telefone, consertos.descricao_servico, consertos.data, consertos.preco FROM cliente, consertos WHERE cliente.id_cliente = consertos.id_cliente and cliente.id_cliente = ?";
            connL = this.conn;
            ps = connL.prepareStatement(SQL);
            ps.setInt(1, id_cliente);
            rs = ps.executeQuery();

            

            while( rs.next()){
              int id_cl = rs.getInt("id_cliente");
              String nome = rs.getString("nome");
              String endereco = rs.getString("endereco");
              String telefone = rs.getString("telefone");
              String descricao_servico = rs.getString("descricao_servico");
              Date data = rs.getDate("data");
              float preco = rs.getFloat("preco");
              
                
               ClienteCon.add(new ClienteConsertos(id_cl, nome, endereco, telefone, descricao_servico, data, preco));
              
            }


        }catch(SQLException sqle){
           System.out.println("Erro ao listar Consultas " + sqle);
        }
        finally{
           Conexao.close(connL,ps);
        }
         return ClienteCon;
    }
    
    public ArrayList listarcl(int id_cliente) {
        PreparedStatement ps = null;
        Connection connL = null;
        ResultSet rs = null;
        ArrayList ClienteCon = new ArrayList();

        try{
            String SQL = "SELECT cliente.id_cliente ,cliente.nome, cliente.telefone, cliente.endereco FROM cliente, consertos WHERE cliente.id_cliente = consertos.id_cliente and cliente.id_cliente = ?";
            connL = this.conn;
            ps = connL.prepareStatement(SQL);
            ps.setInt(1, id_cliente);
            rs = ps.executeQuery();

            

            while( rs.next()){
              int id_clientee = rs.getInt("id_cliente");
              String nome = rs.getString("nome");
              String telefone = rs.getString("telefone");
              String endereco = rs.getString("endereco");
            
              

               ClienteCon.add(new ClienteConsertos(id_clientee ,nome, telefone, endereco));
              
            }


        }catch(SQLException sqle){
           System.out.println("Erro ao listar Consultas " + sqle);
        }
        finally{
           Conexao.close(connL,ps);
        }
         return ClienteCon;
    }
    
    public ArrayList listarpordata(java.util.Date data) {
        PreparedStatement ps = null;
        Connection connL = null;
        ResultSet rs = null;
        ArrayList ClienteCon = new ArrayList();

        try{
            String SQL = "SELECT cliente.id_cliente, cliente.nome, consertos.descricao_servico, consertos.data,consertos.preco FROM cliente, consertos WHERE cliente.id_cliente = conseertos.id_cliente and consertos.data = ?";
            connL = this.conn;
            ps = connL.prepareStatement(SQL);
            java.util.Date dataJAVA = data;
            java.sql.Date dataSQL = new java.sql.Date(dataJAVA.getTime());
            ps.setDate(1, dataSQL);
            rs = ps.executeQuery();
            while( rs.next()){
              int id_cliente = rs.getInt("id_cliente");
            String nome = rs.getString("nome");
            String descricao_servicao = rs.getString("descricao_servico");
            Date dataa = rs.getDate("data");
            float preco = rs.getFloat("preco");
              

               ClienteCon.add(new ClienteConsertos(id_cliente, nome, descricao_servicao, dataa, preco));
              
            }


        }catch(SQLException sqle){
            System.out.println(sqle.getMessage());
        } finally {
            Conexao.close(connL, ps);
        }

        return ClienteCon;
    }
    
    public Cliente procura(int id_cliente) {
        PreparedStatement ps = null;
        Connection connL = null;
        ResultSet rs = null;
        Cliente ClienteCon = new Cliente();

        try{
            String SQL = "SELECT cliente.nome, cliente.id_cliente, consertos.descricao_servico, consertos.data, consertos.preco FROM cliente, consertos WHERE cliente.id_cliente = consertos.id_conserto and cliente.id_cliente = ?";
            connL = this.conn;
            ps = connL.prepareStatement(SQL);
            ps.setInt(1, id_cliente);
            rs = ps.executeQuery();

            

            while( rs.next()){
              
             
            String nome = rs.getString("nome");
            int id = rs.getInt("id_cliente");
            String descricao_servico = rs.getString("descricao_servico");
            Date data = rs.getDate("data");
            float preco = rs.getFloat("preco");
              
             ClienteCon.setNome(nome);
             ClienteCon.setId_cliente(id);
             
              
            }


        }catch(SQLException sqle){
           System.out.println("Erro ao listar Clientes " + sqle);
        }
        finally{
           Conexao.close(connL,ps);
        }
         return ClienteCon;
    }
}
